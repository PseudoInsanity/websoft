<footer>
    <hr>
    <p>I used to be a cool footer, now I am useless.</p>
</footer>