<nav>
    <a href="me.php">Me</a>
    <a href="report.php">Report</a>
    <a href="about.php">About</a>
    <a href="schools.php">Schools</a>
    <a href="flags.php">Flags</a>
    <a href="search.php">Search</a>
    <a href="create.php">Create</a>
</nav>