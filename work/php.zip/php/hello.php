<h1>HELLO WORLD PHP</h1>

<?php
$str = "Hello from the PHP world";
echo $str;

for ($i = 1; $i < 9; $i++) {
    $str .= $i . ", ";
}
?>

<p>
    <?= $str ?>
</p>

<ul>
    <li><a href="hello.html">hello.html</a></li>
    <li><a href="hello.php">hello.php</a></li>
</ul>