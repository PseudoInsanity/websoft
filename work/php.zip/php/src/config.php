<?php

error_reporting(-1);             
ini_set("display_errors", 1);   

// Create an array with the connection details
$dsn = [
    "dsn"       => "mysql:host=127.0.0.1;port=3306;dbname=websoft;charset=UTF8",  
    "username"  => "root",
    "password"  => "",
];